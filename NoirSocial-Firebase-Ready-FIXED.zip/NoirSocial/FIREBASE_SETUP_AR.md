# Noir Social — Firebase setup

تم ربط التطبيق بمشروع Firebase الموجود في `google-services.json`.

## قبل التشغيل
1. Firebase Console → Authentication → Sign-in method → فعّل Email/Password.
2. Firebase Console → Firestore Database → Create database.
3. Firebase Console → Storage → Get started.
4. طبّق محتوى `firestore.rules` في Firestore Rules.
5. طبّق محتوى `storage.rules` في Storage Rules.

## ما يعمل من التطبيق
- إنشاء حساب Email/Password.
- حجز Username فريد بشكل ذري عبر `usernames/{username}`.
- تسجيل الدخول والخروج.
- إعادة تعيين كلمة المرور عبر البريد.
- حفظ ملف المستخدم في `users/{uid}`.
- إنشاء منشورات في `posts` وظهورها مباشرة في الـFeed.
- البحث عن مستخدم بالـusername.
- محادثات ورسائل realtime في `conversations/{conversationId}/messages`.

## ملاحظة
`google-services.json` مرتبط بحزمة Android `com.noirsocial.app`. لا تغيّر package name بعد تسجيل التطبيق في Firebase إلا إذا أعدت تسجيل تطبيق Android جديد في Firebase.
